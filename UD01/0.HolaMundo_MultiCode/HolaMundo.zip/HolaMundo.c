#include <stdio.h>

int main()
{
    printf("Hola mundo!!! \n");
    printf("Programa creado en C por Oscar Fernadez");
    return 0;
}