<?php
echo "Hola Mundo!!! \n";
echo "Programa creado en PHP por Oscar Fernadez";
?>