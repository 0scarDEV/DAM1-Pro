package identificadores;
/**
 * identificadores
 */
public class Identificadores {
    public static void main(String[] args) {
/* A continuación se declaran todas las variables con el siguiente formato:
 *      TipoVariable    NombreVariable  =   ContenidoVariable //Comentario, variable anterior incorrecta.
 */
        int numeroDeTelefono = 647933416;
        long $totalVentas = 16;
        String mi_nombre = "Oscar";
        boolean foreverYoung = true; //4everYoung 
        byte _variable = 1;
        double precioProducto = 12.00; //#precioProducto
        String usuarioEmail = "ofernpast";//usuario-email
        int $saldoCuenta = 2134;
        boolean primeraClase = false;
        byte mi_123_variable = 123;
        String _nombreUsuario = "OFernPast";
        short valor_12345 = 12345; //12345_valor
        String variable = "Variable"; //&variable
        double $precioUnitario = 34.99;
        short contador_de_inventario = 1237; //#contador_de_inventario
        byte miVariableDescuento = 50; //miVariable%descuento
        String producto1 = "Cereales";
        byte tresAñosDeExperiencia = 3; //3añosDeExperiencia
        String _mi_numero_de_cuenta = "ES919218381284182";
        short mi_salario$$ = 1800;
        String $nombreCliente = "Pedrito";
        String variableTemporal = "19/09/2023"; //variable#temporal
        byte _variable99 = 99;//_variable99
        String mi_dirección = "Pazos Fontenla"; //mi_@direccion
        double precioTotal = 127.00; //precio-total
        byte CincoHorasTrabajo = 5; //5HorasTrabajo
        boolean descuento = false; //!descuento
        int codigoDeProducto = 823189311;
        short _MiIdentificador = 0000000;
        byte valorUnitario = 12; //valor#unitario
        
/* Las impresiones en pantalla a continuación solo tratan de eliminar los errores o correcciones, llamando a todas las variables, sin tener un sentido lógico. */
        System.out.println(numeroDeTelefono+$totalVentas+mi_nombre+foreverYoung+_variable+precioProducto+usuarioEmail+$saldoCuenta+primeraClase);
        System.out.println(mi_123_variable+_nombreUsuario+valor_12345+variable+$precioUnitario+contador_de_inventario);
        System.out.println(miVariableDescuento+producto1+tresAñosDeExperiencia+_mi_numero_de_cuenta+mi_salario$$);
        System.out.println($nombreCliente+variableTemporal+_variable99+mi_dirección+precioTotal+CincoHorasTrabajo+descuento+codigoDeProducto+_MiIdentificador+valorUnitario);
    }
}