package buclesparaninfo;

public class EP0315 {
    // Óscar Fernández Pastoriza
    /* EP0315. Diseña una aplicación que dibuje el triángulo de Pascal, para n filas. Numerando las filas y elementos desde 0, la fórmula para obtener el m-ésimo elemento de la n-ésima fila es
                        E(n, m) = n!  /  m!(n - m)!
        Donde n! es el factorial de n.
    
    Un ejemplo de triángulo de Pascal con 5 filas (n = 4) es :
    
        1
        1 1
        1 2 1
        1 3 3 1
        1 4 6 4 1 */
    public static void main(String[] args) {

        

    }
}
